const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para processar JSON e servir arquivos estáticos da pasta 'public'
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Banco de dados em memória para simulação/testes
const agendamentos = [];

// Endpoint para processar o agendamento
app.post('/api/agendar', (req, res) => {
    const { nome, telefone, servico, data, hora } = req.body;

    // Validação básica no backend
    if (!nome || !telefone || !servico || !data || !hora) {
        return res.status(400).json({ success: false, error: 'Todos os campos são obrigatórios.' });
    }

    const novoAgendamento = {
        id: agendamentos.length + 1,
        nome,
        telefone,
        servico,
        data,
        hora,
        dataRegistro: new Date()
    };

    // Salva na lista (em produção, aqui iria o insert do Banco de Dados)
    agendamentos.push(novoAgendamento);

    // Formatação da mensagem para o WhatsApp do Neto
    const numeroWhats = '5511963198279';
    const mensagemTexto = `💈 *Novo Agendamento - Neto Cabeleireiro* 💈\n\n` +
                          `👤 *Cliente:* ${nome}\n` +
                          `📞 *Contato:* ${telefone}\n` +
                          `✂️ *Serviço:* ${servico}\n` +
                          `📅 *Data:* ${data}\n` +
                          `⏰ *Horário:* ${hora}\n\n` +
                          `_Confirmado via sistema web._`;

    const urlWhatsapp = `https://api.whatsapp.com/send?phone=${numeroWhats}&text=${encodeURIComponent(mensagemTexto)}`;

    // Retorna sucesso e a URL que o frontend vai abrir
    return res.status(201).json({
        success: true,
        message: 'Agendamento salvo com sucesso no backend!',
        whatsappUrl: urlWhatsapp
    });
});

// Endpoint extra para você listar e checar os agendamentos salvos via API/Postman
app.get('/api/agendamentos', (req, res) => {
    res.json(agendamentos);
});

app.listen(PORT, () => {
    console.log(`🚀 Servidor ativo em: http://localhost:${PORT}`);
});